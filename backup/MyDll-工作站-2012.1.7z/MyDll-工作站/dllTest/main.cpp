
#include <IOSTREAM>
#include <windows.h>
#include <process.h>
#include "SmartComOperation.h"
#include "Communicator.h"
#include "SmartCom.h"

#pragma comment(lib, "SmartCom.lib" )
/************************************************************************/
/* smartcom�����Լ�ʵ�ֵ�string�࣬���������ռ�smartcom�У�
֧�ֻ������ַ���������

��ʹ���������ͨ�ŵ�api֮ǰ����Ҫ��ʼ��ͨ�ţ�ÿ��api����Ҫһ��
Communicator�Ĳ�����                                                                     */
/************************************************************************/
FILE* fp;
CRITICAL_SECTION cs_rw;
DWORD WINAPI fun(LPVOID);
void pushError(const char* str,int id);

int main()
{

	int i=0;unsigned long id=0;
	fp=fopen("log.txt","wt+");
	InitializeCriticalSection(&cs_rw);
	for(i=10001;i<=10008;i++)
	{
		CreateThread(NULL,0,fun,(void*)(i),0,&id);
		//CreateThread(NULL,0,fun,(void*)(i),0,&id);
	}
	char ch;
	scanf("%c",&ch);
	return 0;
}

DWORD WINAPI fun(LPVOID p)
{
	int ret;int macno;
	Communicator* comm1,*comm2;
	SmartCom::string str;
	char ch[64];//
	Communicator comm;
	int threaID=GetCurrentThreadId();/*
	for(int i=0;i<40;i++)
	{
		//GetOneUDPCommunicator(comm,"192.168.1.138",(int)p);
		//comm1=GetUDPCommunicator("192.168.1.1",10000);
		//comm1=GetUDPCommunicator("192.168.1.1",10000);
		comm1=GetUDPCommunicator("192.168.1.138",(int)p);
		//comm1=GetCOMCommunicator(1);
		int ret=0;
		ret=ResetCard(comm1,str);
		pushError(str.c_str(),threaID);
		ret=CardApdu(comm1,"00820000083132333435363738",str);
		pushError(str.c_str(),threaID);
		ret=CardApdu(comm1,"00FE000000",str);
		pushError(str.c_str(),threaID);
		ret=CardApdu(comm1,"00F900FF00",str);
		pushError(str.c_str(),threaID);
		ret=CardApdu(comm1,"00AA0200033F0000",str);
		pushError(str.c_str(),threaID);
		ret=CardApdu(comm1,"00F8000080805FFFFFFFFFFFFFFFFFFF415CFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8024FFFFFF0D9A940000070100030005012831FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF75D0007581C278FF760475A600E478087ABBF608DAFC",str);
		pushError(str.c_str(),threaID);
		ret=CardApdu(comm1,"00F800808031AF743B512F31CC900040E493A3FAE493512FA3DAF975F00090C0405105B4FF02800AF50878097A0480485105F0A365F0F5F070F67A38DAFEC3E5829440FA90C041E07005BA03E380115410641070DBA3E06494600CE0641170D090C0405155800D90C040515575CA0075CB40D20D78087A054387105105F608DAFA758DFE75",str);
		pushError(str.c_str(),threaID);
		ret=CardApdu(comm1,"00F80100808B8C300D06758DFF758BC0D28E308FFDC28FC28EE50864A0600EE50864807006E50964806002807F85081475080012D8944002806D30E012E50C600EFA90C000E509512F5105F0A3DAFAE4A20D13F58C75A882D28C12D8BBC28C78FFE664046002016190C7C7E06008E4F090C7C0125617E508600BE509512FAA0890C0005155",str);
		pushError(str.c_str(),threaID);
		ret=CardApdu(comm1,"00F8018080758DFA758B30300D06758DF3758B80D28E308FFDC28FC28EE50D512FE50E512F01EF750D6D8003750D6E750E0080D1516F75A80075CA0175CB7475FB0175C800D2AF758951750D9A750E1622D20B125825502412DCC0C20B12BE15740112BE81A2E4920812C1E8C21F90C77EE47A0212C81CE4F0126B4FD214C227C222C224C2",str);
		pushError(str.c_str(),threaID);
		ret=CardApdu(comm1,"00F80200802512B0A322C0047C0675C804E5CC20E70280F9E5CC30E10B00000075C804DCECC38006000000E5C9D375C800D00422C0047C06F5C975C806E5CC20E70280F9E5CC30E30A000075C806DCEDC38001D375C800D00422E0512FA3DAFA22C0E0C0D07460512FE4A20D13F58CD0D0D0E032E4F5B475B33FF5B3F5B375B40475B33FF5",str);
		pushError(str.c_str(),threaID);
		ret=CardApdu(comm1,"00F8028080B375B34075B40175B33FF5B375B38075B40575B325F5B375B3C075B40775B30F75B304F5B322C002C003C0D07A007B73EBC333CA3375B40275B30FF5B38AB3D0D0D003D0022222FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF1204A3C0E01204CCD0E01204B975A60790C64C7E0E1253D490C003E0",str);
		pushError(str.c_str(),threaID);
		ret=ReleaseCommunicator(comm1);
	//	printf("thread:%d,comm1:%08X,ret=%08X\r\n",GetCurrentThreadId(),comm1,ret);
	//	Sleep(1000);
	//	delete comm1;
	}
	printf("%d:exit\r\n",GetCurrentThreadId());
	*/
	for(int i=0;i<30;i++)
	{
       comm1=GetUDPCommunicator("192.168.1.138",(int)p);
	   //comm2=GetUDPCommunicator("192.168.1.138",(int)p);
	   if(comm1==0)
	   {
		   pushError("get comm1 ret 0",(int)p);
	   }
	   if(comm2==0)
	   {
		   pushError("get comm2 ret 0",(int)p);
	   }
	   ret=SetSendInterval(comm1,0);
	   ret=DisableAutoAnswer(comm1);
	   ret=GetDevIDAndMacNo(comm1,str,macno);
       if(ret!=0)
		   pushError("getdevid error",(int)p);
	   ret=ResetCard(comm1,str);
	   pushError((char*)str.c_str(),(int)p);
	   ret=ClearMem(comm1);
	   ret=DownloadFile(comm1,FILE_BODY,"body.bin");
	   if(ret!=0)
		   pushError("download file error",(int)p);
	   ret=DownloadFile(comm1,FILE_HEAD,"head.bin");
	   if(ret!=0)
		   pushError("download file error",(int)p);
	   ret=ExcuteMulAPDU(comm1,135);
	   while(SC_EXCUTING==(ret=CheckBatchResult(comm1,str)));
	   if(ret!=135)
	   {
		   sprintf(ch,"ret=%d,-----retcode=%s----",ret,str.c_str());
		   pushError(ch,(int)p);
	   }
	   else
	   {
           sprintf(ch,"ret=%d,retcode=%s",ret,str.c_str());
		   pushError(ch,(int)p);
	   }
	   ret=ShutdownCard(comm1);
	   ret=ReleaseCommunicator(comm1);
	   if(ret==SCERR_OPERROR)
	   {
          pushError("release comm1:operror",(int)p);
	   }
	   else if(ret==SCERR_INVALID_COMM)
	   {
		   pushError("release comm1:invalid comm",(int)p);
	   }
	  // ret=ReleaseCommunicator(comm2);
	}//	*/	
	return 0;
}

void pushError(const char* str,int id)
{
	DWORD t=GetTickCount();
	DWORD sec=t/1000;
	DWORD milisec=t%1000;
	char ch1[128];
    sprintf(ch1,"macno:%d,time:%us%u,desc:%s\r\n",id,sec,milisec,str);
	EnterCriticalSection(&cs_rw);
	printf("%s",ch1);
	fwrite(ch1,strlen(ch1),1,fp);
	LeaveCriticalSection(&cs_rw);
}
