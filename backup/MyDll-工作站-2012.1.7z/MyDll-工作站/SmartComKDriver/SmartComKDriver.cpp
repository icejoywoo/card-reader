/************************************************************************
* �ļ�����:SmartComKDriver.cpp                                                 
* ��    ��:������
* �������:2011-12-1
*************************************************************************/
#include "SmartComKDriver.h"
#include "../SmartComDefine.h"
#include "stdio.h"


#define IOCTL_WRITE CTL_CODE(FILE_DEVICE_UNKNOWN,0x800,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_APDU  CTL_CODE(FILE_DEVICE_UNKNOWN,0X801,METHOD_NEITHER,FILE_ANY_ACCESS)

/************************************************************************
* ��������:DriverEntry
* ��������:��ʼ���������򣬶�λ������Ӳ����Դ�������ں˶���
* �����б�:
      pDriverObject:��I/O�������д���������������
      pRegistryPath:����������ע������е�·��
* ���� ֵ:���س�ʼ������״̬
*************************************************************************/
#pragma INITCODE 
extern "C" NTSTATUS DriverEntry(IN PDRIVER_OBJECT pDriverObject,
								IN PUNICODE_STRING pRegistryPath)
{
	KdPrint(("Enter DriverEntry\n"));

	pDriverObject->DriverExtension->AddDevice = SCAddDevice;
	pDriverObject->MajorFunction[IRP_MJ_PNP] = SCPnp;
	pDriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = SCDispatchRoutine;
	pDriverObject->MajorFunction[IRP_MJ_CREATE] = SCDispatchRoutine;
	pDriverObject->MajorFunction[IRP_MJ_READ] = ReadMyDevice;
	pDriverObject->MajorFunction[IRP_MJ_WRITE] = WriteMyDevice;
	pDriverObject->MajorFunction[IRP_MJ_CLOSE] = SCDispatchRoutine;
	pDriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL]=DeviceIOCtl;
	pDriverObject->DriverUnload = SCUnload;

	KdPrint(("Leave DriverEntry\n"));
	return STATUS_SUCCESS;
}

/************************************************************************
* ��������:SCAddDevice
* ��������:�������豸
* �����б�:
      DriverObject:��I/O�������д���������������
      PhysicalDeviceObject:��I/O�������д������������豸����
* ���� ֵ:�����������豸״̬
*************************************************************************/
#pragma PAGEDCODE
NTSTATUS SCAddDevice(IN PDRIVER_OBJECT DriverObject,
                           IN PDEVICE_OBJECT PhysicalDeviceObject)
{ 
	PAGED_CODE();
	KdPrint(("Enter SCAddDevice\n"));
	//�����豸����������
	UCHAR str[128];

	strcpy((char*)str,"\\DosDevices\\");
	strcpy((char*)str+strlen("\\DosDevices\\"),DEVICE_NAME);
	UNICODE_STRING ustr;
	ANSI_STRING astr;
	RtlInitAnsiString(&astr,(const char*)str);
	RtlAnsiStringToUnicodeString(&ustr,&astr,TRUE);
	KdPrint(("devicename:%s",str));
	NTSTATUS status=CreateDevice(L"\\Device\\SmartComProxyDevice",ustr.Buffer,DriverObject,PhysicalDeviceObject);
   // return status;
    //RtlFreeUnicodeString(&ustr);
	//dump
	PDEVICE_OBJECT pdo=DriverObject->DeviceObject,pdo1;
	int i=1;
	for(;pdo;pdo=pdo->NextDevice)
	{
		for(pdo1=pdo;pdo1;pdo1=pdo1->AttachedDevice)
		{
            KdPrint(("device %d,addr:0X%08X\n",i,pdo1));
			KdPrint(("attached device 0X%08X\n",pdo1->AttachedDevice));
			KdPrint(("next device 0X%08X\n",pdo1->NextDevice));
		    KdPrint(("device stacksize %d\n",pdo1->StackSize));
			i++;
		}		
	}

	KdPrint(("leave SCAddDevice\n"));
	return status;
}

#pragma  PAGEDCODE
NTSTATUS CreateDevice(IN PWCHAR dename,IN PWCHAR syname,IN PDRIVER_OBJECT driveObject,IN PDEVICE_OBJECT deObject)
{
    PAGED_CODE();
	KdPrint(("creating device %s \n",dename));
    NTSTATUS status;
	PDEVICE_OBJECT pdo;
    UNICODE_STRING devname;
	RtlInitUnicodeString(&devname,dename);
	status=IoCreateDevice(driveObject,
		sizeof(DEVICE_EXTENSION),
		&devname,
		FILE_DEVICE_UNKNOWN,
		0,
		FALSE,
		&pdo);
	if(!NT_SUCCESS(status))
	{
		KdPrint(("create device error\n"));
        return status;
	}
	PDEVICE_EXTENSION pdx=(PDEVICE_EXTENSION)pdo->DeviceExtension;
	pdx->fdo=pdo;
	pdx->NextStackDevice=IoAttachDeviceToDeviceStack(pdo,deObject);
	pdx->ustrDeviceName=devname;

	KdPrint(("next stackdevice:%08X,deobject:%08X,pdo:%08X\n",pdx->NextStackDevice,deObject,pdo));
	UNICODE_STRING sylinkname;
	RtlInitUnicodeString(&sylinkname,syname);
	status=IoCreateSymbolicLink(&sylinkname,&devname);
	if(!NT_SUCCESS(status))
	{
		KdPrint(("create symbo link error"));
		IoDeleteDevice(pdo);
		return status;
	}

	pdx->ustrSymLinkName=sylinkname;
	pdo->Flags|=DO_BUFFERED_IO|DO_POWER_PAGABLE;
	pdo->Flags&=~DO_DEVICE_INITIALIZING;

	return status;
}

/************************************************************************
* ��������:SCPnpHandler
* ��������:��PNP IRP����ȱʡ����
* �����б�:
      pdx:�豸�������չ
      Irp:��IO�����
* ���� ֵ:����״̬
*************************************************************************/ 
#pragma PAGEDCODE
NTSTATUS SCPnpHandler(PDEVICE_EXTENSION pdx, PIRP Irp)
{
	PAGED_CODE();
//	KdPrint(("Enter DefaultPnpHandler\n"));
	IoSkipCurrentIrpStackLocation(Irp);
//	KdPrint(("Leave DefaultPnpHandler\n"));
	return IoCallDriver(pdx->NextStackDevice, Irp);
}

/************************************************************************
* ��������:HandleRemoveDevice
* ��������:��IRP_MN_REMOVE_DEVICE IRP���д���
* �����б�:
      fdo:�����豸����
      Irp:��IO�����
* ���� ֵ:����״̬
*************************************************************************/
#pragma PAGEDCODE
NTSTATUS HandleRemoveDevice(PDEVICE_EXTENSION pdx, PIRP Irp)
{
	PAGED_CODE();
	KdPrint(("Enter HandleRemoveDevice\n"));

	Irp->IoStatus.Status = STATUS_SUCCESS;
	NTSTATUS status = SCPnpHandler(pdx, Irp);
	IoDeleteSymbolicLink(&(UNICODE_STRING)pdx->ustrSymLinkName);

    //����IoDetachDevice()��fdo���豸ջ���ѿ���
    if (pdx->NextStackDevice)
        IoDetachDevice(pdx->NextStackDevice);
	
    //ɾ��fdo��
    IoDeleteDevice(pdx->fdo);
	KdPrint(("Leave HandleRemoveDevice\n"));
	return status;
}

/************************************************************************
* ��������:SCPnp
* ��������:�Լ��弴��IRP���д���
* �����б�:
      fdo:�����豸����
      Irp:��IO�����
* ���� ֵ:����״̬
*************************************************************************/
#pragma PAGEDCODE
NTSTATUS SCPnp(IN PDEVICE_OBJECT fdo,
                        IN PIRP Irp)
{
	PAGED_CODE();

//	KdPrint(("Enter HelloWDMPnp\n"));
	NTSTATUS status = STATUS_SUCCESS;
	PDEVICE_EXTENSION pdx = (PDEVICE_EXTENSION) fdo->DeviceExtension;
	PIO_STACK_LOCATION stack = IoGetCurrentIrpStackLocation(Irp);
	static NTSTATUS (*fcntab[])(PDEVICE_EXTENSION pdx, PIRP Irp) = 
	{
		SCPnpHandler,		// IRP_MN_START_DEVICE
		SCPnpHandler,		// IRP_MN_QUERY_REMOVE_DEVICE
		HandleRemoveDevice,		// IRP_MN_REMOVE_DEVICE
		SCPnpHandler,		// IRP_MN_CANCEL_REMOVE_DEVICE
		SCPnpHandler,		// IRP_MN_STOP_DEVICE
		SCPnpHandler,		// IRP_MN_QUERY_STOP_DEVICE
		SCPnpHandler,		// IRP_MN_CANCEL_STOP_DEVICE
		SCPnpHandler,		// IRP_MN_QUERY_DEVICE_RELATIONS
		SCPnpHandler,		// IRP_MN_QUERY_INTERFACE
		SCPnpHandler,		// IRP_MN_QUERY_CAPABILITIES
		SCPnpHandler,		// IRP_MN_QUERY_RESOURCES
		SCPnpHandler,		// IRP_MN_QUERY_RESOURCE_REQUIREMENTS
		SCPnpHandler,		// IRP_MN_QUERY_DEVICE_TEXT
		SCPnpHandler,		// IRP_MN_FILTER_RESOURCE_REQUIREMENTS
		SCPnpHandler,		// 
		SCPnpHandler,		// IRP_MN_READ_CONFIG
		SCPnpHandler,		// IRP_MN_WRITE_CONFIG
		SCPnpHandler,		// IRP_MN_EJECT
		SCPnpHandler,		// IRP_MN_SET_LOCK
		SCPnpHandler,		// IRP_MN_QUERY_ID
		SCPnpHandler,		// IRP_MN_QUERY_PNP_DEVICE_STATE
		SCPnpHandler,		// IRP_MN_QUERY_BUS_INFORMATION
		SCPnpHandler,		// IRP_MN_DEVICE_USAGE_NOTIFICATION
		SCPnpHandler,		// IRP_MN_SURPRISE_REMOVAL
	};

	ULONG fcn = stack->MinorFunction;
	if (fcn >= arraysize(fcntab))
	{						// δ֪���ӹ��ܴ���
		status = SCPnpHandler(pdx, Irp); // some function we don't know about
		return status;
	}						

#if DBG
	static char* fcnname[] = 
	{
		"IRP_MN_START_DEVICE",
		"IRP_MN_QUERY_REMOVE_DEVICE",
		"IRP_MN_REMOVE_DEVICE",
		"IRP_MN_CANCEL_REMOVE_DEVICE",
		"IRP_MN_STOP_DEVICE",
		"IRP_MN_QUERY_STOP_DEVICE",
		"IRP_MN_CANCEL_STOP_DEVICE",
		"IRP_MN_QUERY_DEVICE_RELATIONS",
		"IRP_MN_QUERY_INTERFACE",
		"IRP_MN_QUERY_CAPABILITIES",
		"IRP_MN_QUERY_RESOURCES",
		"IRP_MN_QUERY_RESOURCE_REQUIREMENTS",
		"IRP_MN_QUERY_DEVICE_TEXT",
		"IRP_MN_FILTER_RESOURCE_REQUIREMENTS",
		"",
		"IRP_MN_READ_CONFIG",
		"IRP_MN_WRITE_CONFIG",
		"IRP_MN_EJECT",
		"IRP_MN_SET_LOCK",
		"IRP_MN_QUERY_ID",
		"IRP_MN_QUERY_PNP_DEVICE_STATE",
		"IRP_MN_QUERY_BUS_INFORMATION",
		"IRP_MN_DEVICE_USAGE_NOTIFICATION",
		"IRP_MN_SURPRISE_REMOVAL",
	};

//	KdPrint(("PNP Request (%s)\n", fcnname[fcn]));
#endif // DBG

	status = (*fcntab[fcn])(pdx, Irp);
//	KdPrint(("Leave HelloWDMPnp\n"));
	return status;
}

/************************************************************************
* ��������:SCDispatchRoutine
* ��������:��ȱʡIRP���д���
* �����б�:
      fdo:�����豸����
      Irp:��IO�����
* ���� ֵ:����״̬
*************************************************************************/
#pragma PAGEDCODE
NTSTATUS SCDispatchRoutine(IN PDEVICE_OBJECT fdo,
								 IN PIRP Irp)
{
	PAGED_CODE();
	KdPrint(("Enter HelloWDMDispatchRoutine\n"));
	Irp->IoStatus.Status = STATUS_SUCCESS;
	Irp->IoStatus.Information = 0;	// no bytes xfered
	IoCompleteRequest( Irp, IO_NO_INCREMENT );
	KdPrint(("Leave HelloWDMDispatchRoutine\n"));
	return STATUS_SUCCESS;
}

/************************************************************************
* ��������:SCUnload
* ��������:�������������ж�ز���
* �����б�:
      DriverObject:��������
* ���� ֵ:����״̬
*************************************************************************/
#pragma PAGEDCODE
void SCUnload(IN PDRIVER_OBJECT DriverObject)
{
	PAGED_CODE();
	KdPrint(("Enter HelloWDMUnload\n"));
	KdPrint(("Leave HelloWDMUnload\n"));
}

//��ȡ�豸
NTSTATUS ReadMyDevice(IN PDEVICE_OBJECT fdo,
								 IN PIRP Irp)
{
	KdPrint(("enter read fun\n"));
	//�����жϼ���
//	KIRQL oldIrq;
	KdPrint(("current irq:%d\n",KeGetCurrentIrql()));
//	KeRaiseIrql(DISPATCH_LEVEL,&oldIrq);
	PDEVICE_EXTENSION pdx=(PDEVICE_EXTENSION)fdo->DeviceExtension;
	while(pdx->i<0xffffffff)
	{
		pdx->i++;
	}
	pdx->i=0;
	PIO_STACK_LOCATION stack=IoGetCurrentIrpStackLocation(Irp);
	ULONG len=stack->Parameters.Read.Length;
	Irp->IoStatus.Information=len;
	RtlFillMemory(Irp->AssociatedIrp.SystemBuffer,len,0xaa);
	Irp->IoStatus.Status=STATUS_SUCCESS;
	IoCompleteRequest(Irp,IO_NO_INCREMENT);
	KdPrint(("leave read fun\n"));
//	KeLowerIrql(oldIrq);
	return STATUS_SUCCESS;
}

NTSTATUS DeviceIOCtl(IN PDEVICE_OBJECT fdo,
								 IN PIRP Irp)
{
	KdPrint(("enter DeviceIOCtrl\n"));
	PIO_STACK_LOCATION stackloc=IoGetCurrentIrpStackLocation(Irp);
    ULONG cbin=stackloc->Parameters.DeviceIoControl.InputBufferLength;
	ULONG cbout=stackloc->Parameters.DeviceIoControl.OutputBufferLength;
	ULONG code=stackloc->Parameters.DeviceIoControl.IoControlCode;
    /////
	int ret=0;
	KIOCTRLEX kioex;
	KIOCTRL_APDU kioapdu;
	UCHAR* inbuffer=0;
    UCHAR* outbuffer=0;
	switch(code)
	{
	case IOCTL_WRITE:
		//ȡ���ļ������com���,inbuff���ݽṹΪ�ļ������com�������־������,��ʱ		
		inbuffer=(UCHAR*)Irp->AssociatedIrp.SystemBuffer;
	    outbuffer=(UCHAR*)Irp->AssociatedIrp.SystemBuffer;
		RtlCopyMemory(&kioex.kioctrl,inbuffer,sizeof(KIOCTRL));
		kioex.sleep_time=RtlConvertLongToLargeInteger(-100000);//�߳�ÿ��˯10����
		kioex.timeout_count=kioex.kioctrl.timeout/10;//��Ҫ�ӳټ���10����
        ret=DownloadFile(kioex);
		RtlCopyMemory(outbuffer,&ret,4);
		Irp->IoStatus.Information=4;
		break;
	case IOCTL_APDU:	
		inbuffer=(UCHAR*)stackloc->Parameters.DeviceIoControl.Type3InputBuffer;
		outbuffer=(UCHAR*)Irp->UserBuffer;
		KdPrint(("inbuffer:%08X,outbuffer:%08X\n",inbuffer,outbuffer));
		RtlCopyMemory(&kioapdu,inbuffer,sizeof(KIOCTRL_APDU));
		UCHAR sw1=0,sw2=0;
		ret=ExcuteMulAPDU(kioapdu,sw1,sw2);
		RtlCopyMemory(outbuffer,&ret,4);
		char ch[5];
		sprintf(ch,"%02X",sw1);
		sprintf(ch+2,"%02X",sw2);
		ch[4]=0;
		RtlCopyMemory(outbuffer+4,ch,5);
		Irp->IoStatus.Information=9;
		break;
	}
	KdPrint(("ret=%d\n",ret));
	Irp->IoStatus.Status=STATUS_SUCCESS;
	IoCompleteRequest(Irp,IO_NO_INCREMENT);
	KdPrint(("leave DeviceIOCtrl\n"));
	return STATUS_SUCCESS;
}

//д�豸
NTSTATUS WriteMyDevice(IN PDEVICE_OBJECT fdo,
					  IN PIRP Irp)
{
	Irp->IoStatus.Information=0;
	Irp->IoStatus.Status=STATUS_SUCCESS;
	IoCompleteRequest(Irp,IO_NO_INCREMENT);
	return STATUS_SUCCESS;
}