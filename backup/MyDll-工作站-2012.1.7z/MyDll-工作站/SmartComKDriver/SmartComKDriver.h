/************************************************************************
* �ļ�����:SmartComKDriver.h                                                 
* ��    ��:������
* �������:2011-12-1
*************************************************************************/
#ifndef __SmartComKDriver_H__
#define __SmartComKDriver_H__

#ifdef __cplusplus
extern "C"
{
#endif
#include <wdm.h>
#ifdef __cplusplus
}
#endif 

#include "smartcom411.h"

typedef struct _DEVICE_EXTENSION
{
	PDEVICE_OBJECT fdo;
	PDEVICE_OBJECT NextStackDevice;
	unsigned int i;
	UNICODE_STRING ustrDeviceName;	// �豸��
	UNICODE_STRING ustrSymLinkName;	// ����������
} DEVICE_EXTENSION, *PDEVICE_EXTENSION;

#define PAGEDCODE code_seg("PAGE")
#define LOCKEDCODE code_seg()
#define INITCODE code_seg("INIT")

#define PAGEDDATA data_seg("PAGE")
#define LOCKEDDATA data_seg()
#define INITDATA data_seg("INIT")

#define arraysize(p) (sizeof(p)/sizeof((p)[0]))

NTSTATUS SCAddDevice(IN PDRIVER_OBJECT DriverObject,
                           IN PDEVICE_OBJECT PhysicalDeviceObject);
NTSTATUS SCPnp(IN PDEVICE_OBJECT fdo,
					 IN PIRP Irp);
NTSTATUS SCDispatchRoutine(IN PDEVICE_OBJECT fdo,
								 IN PIRP Irp);
NTSTATUS CreateDevice(IN PWCHAR dename,IN PWCHAR syname,IN PDRIVER_OBJECT driveObject,IN PDEVICE_OBJECT deObject);
void SCUnload(IN PDRIVER_OBJECT DriverObject);

extern "C"
NTSTATUS DriverEntry(IN PDRIVER_OBJECT DriverObject,
                     IN PUNICODE_STRING RegistryPath);

NTSTATUS ReadMyDevice(IN PDEVICE_OBJECT fdo,
					  IN PIRP Irp);
NTSTATUS WriteMyDevice(IN PDEVICE_OBJECT fdo,
					   IN PIRP Irp);

NTSTATUS DeviceIOCtl(IN PDEVICE_OBJECT fdo,
					 IN PIRP Irp);

#endif