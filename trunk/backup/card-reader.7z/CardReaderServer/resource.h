//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CardReaderServer.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CARDREADERSERVER_DIALOG     102
#define IDD_SERVERSETTING_DIALOG        103
#define IDR_MAINFRAME                   128
#define IDI_ICON_SERVER                 136
#define IDD_DIALOG1                     137
#define IDC_EDIT1                       1000
#define IDC_EDIT_PORT                   1000
#define IDC_BUTTON_SENDCMD              1001
#define IDC_EDIT_LOG                    1002
#define IDC_BUTTON_CLEAR                1003
#define IDC_BUTTON_START                1004
#define IDC_BUTTON_STOP                 1005
#define IDC_BUTTON_LOG                  1006
#define IDC_BUTTON_SETTING              1007
#define IDC_BUTTON_RESTART              1008
#define IDC_TREE_VIEW                   1009
#define IDC_EDIT_READERCOUNT            1018
#define IDC_IPADDRESS1                  1019
#define IDC_IPADDRESS2                  1020
#define IDC_IPADDRESS3                  1021
#define IDC_IPADDRESS4                  1022

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
