//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CardReaderServer.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CARDREADERSERVER_DIALOG     102
#define IDD_SERVERSETTING_DIALOG        103
#define IDR_MAINFRAME                   128
#define IDI_ICON_SERVER                 136
#define IDI_ICON_SERVERROOT             139
#define IDC_EDIT1                       1000
#define IDC_EDIT_PORT                   1000
#define IDC_EDIT_ERRORS                 1000
#define IDC_BUTTON_SENDCMD              1001
#define IDC_EDIT_LOG                    1002
#define IDC_BUTTON_CLEAR                1003
#define IDC_BUTTON_START                1004
#define IDC_BUTTON_STOP                 1005
#define IDC_BUTTON_LOG                  1006
#define IDC_BUTTON_SETTING              1007
#define IDC_BUTTON_RESTART              1008
#define IDC_TREE_CLIENTS                1009
#define IDC_BUTTON_ADD                  1025
#define IDC_BUTTON_DEL                  1026
#define IDC_EDIT_WARNS                  1036
#define IDC_LIST_READERS                1037
#define IDC_EDIT_READER_ID              1038

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        140
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1039
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
